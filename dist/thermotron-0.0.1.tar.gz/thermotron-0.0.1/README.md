# thermotron
Python package for controlling Thermotron thermal chambers

This is a package for controlling Thermotron thermal chambers with Python. 

This is a basic package for controlling certain GPIB interface Thermotron machines. 
More features may be added in the future. Please feel free to contribute. 
